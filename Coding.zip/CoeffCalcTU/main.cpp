/***************** Coefficient Calculation for 5 initial cancer risk gene with 204 miRNAs for 53 tumor samples******************/

#include<bits/stdc++.h>

    double mRNA[1500][1500];
    double miRNA[1500][1500];

     FILE  *inFile2, *inFile3,*outFile;

     char fname1[20];
     char fname2[20];


int FGFR3_coefficient(FILE *, FILE *, int , int,int ,int);
int HRAS_coefficient(FILE *, FILE *, int , int,int ,int);
int RB1_coefficient(FILE *, FILE *, int , int,int ,int);
int TP53_coefficient(FILE *, FILE *, int , int,int ,int);
int TSC1_coefficient(FILE *, FILE *, int , int,int ,int);

void fileInput();

int main()
{
     fileInput();
}

/***************File Input **********/

void fileInput()
{
    inFile2 = fopen("miRNA_TU.txt", "r");
    inFile3 =  fopen("mRNA_TU.txt","r");

   FGFR3_coefficient(inFile2,inFile3,53,204,53,5);
   HRAS_coefficient(inFile2,inFile3,53,204,53,5);
   RB1_coefficient(inFile2,inFile3,53,204,53,5);
   TP53_coefficient(inFile2,inFile3,53,204,53,5);
   TSC1_coefficient(inFile2,inFile3,53,204,53,5);
}

/*******************************FGFR3 Coefficient***********************************/

int FGFR3_coefficient (FILE *inFilex,FILE *inFiley, int rows1, int columns1,int rows2, int columns2)
{

    double coeff[1500] ;
    double num[1500];
    double deno[1500];

    double xymul[1500] ={0.0};
    double xysum[1500] ={0.0};
    double xsum[1500]= {0.0};
    double ysum= 0.0;
    double xsqr[1500]={0.0};
    double ysqr[1500]={0.0};
    double xsqr_sum[1500]={0.0};
    double ysqr_sum=0.0;
    if (inFilex == NULL)
    {
        printf("\nFailed to open file.\n");
        exit(1);
    }

     if (inFiley == NULL)
    {
        printf("\nFailed to open file.\n");
        exit(1);
    }

     outFile = fopen("FGFR3_TU_coefficient.txt","w");
    if(outFile==NULL)
    {
        printf("The file was not opened.");
        exit(1);
    }


     for(int i=0;i<columns1;)
{
    printf("\n");

    for(int j=0;j<rows1;j++)
    {
        fscanf(inFilex, "%lf",&miRNA[i][j]);
      //  fprintf(outFile," mRNA[%d][%d]  %lf\n",i,j,miRNA[i][j]);

        }
        i++;
    }



     for(int i=0;i<columns2;)
     {
    for(int j=0;j<rows2;j++)
    {
        printf("\n");
        fscanf(inFiley, "%lf",&mRNA[i][j]);
        //fprintf(outFile3," mRNA[%d][%d]  %lf\n",i,j,mRNA[i][j]);

        }
         i++;
     }
    // for(int i=0;i<columns;)
    {
        for(int j=0;j<rows1;)
        {
            ysum += mRNA[0][j];
            ysqr_sum += mRNA[0][j]*mRNA[0][j];
          //  printf("ysum: %lf\n",ysum);
          //  printf("ysqs: %lf\n",ysqr_sum);
            j++;
        }
    }

   for(int i=0;i<columns1;)
    {
      for(int j=0;j<rows1;)
      {
          xymul[j] = miRNA[i][j]*mRNA[0][j];
          xsqr[j] = miRNA[i][j]*miRNA[i][j];
          xsum[i] += miRNA[i][j];

          xsqr_sum[i] += xsqr[j];

          xysum[i] += xymul[j];

           j++;

      }

      num[i] = 1.0 * ((rows1 * xysum[i]) - (xsum[i] * ysum));
       deno[i] = 1.0 * ((rows1 * xsqr_sum[i] - xsum[i] * xsum[i])* (rows1 * ysqr_sum - ysum * ysum));

        //calculate correlation coefficient

       coeff[i] = (num[i] / sqrt(deno[i]));
       fprintf(outFile,"%lf\n",coeff[i]);
      i++;
    }


   printf("File copied successfully!");
    fclose(inFilex);
    fclose(inFiley);
    fclose(outFile);
    return 0;
}

/*******************************HRAS Coefficient***********************************/

int HRAS_coefficient (FILE *inFilex,FILE *inFiley, int rows1, int columns1,int rows2, int columns2)
{

    double coeff[1500] ;
    double num[1500];
    double deno[1500];

    double xymul[1500] ={0.0};
    double xysum[1500] ={0.0};
    double xsum[1500]= {0.0};
    double ysum= 0.0;
    double xsqr[1500]={0.0};
    double ysqr[1500]={0.0};
    double xsqr_sum[1500]={0.0};
    double ysqr_sum=0.0;
    if (inFilex == NULL)
    {
        printf("\nFailed to open file.\n");
        exit(1);
    }

     if (inFiley == NULL)
    {
        printf("\nFailed to open file.\n");
        exit(1);
    }

     outFile = fopen("HRAS_TU_coefficient.txt","w");
    if(outFile==NULL)
    {
        printf("The file was not opened.");
        exit(1);
    }


     for(int i=0;i<columns1;)
{
    printf("\n");

    for(int j=0;j<rows1;j++)
    {
        fscanf(inFilex, "%lf",&miRNA[i][j]);
       // fprintf(outFile," mRNA[%d][%d]  %lf\n",i,j,miRNA[i][j]);

        }
        i++;
    }



     for(int i=0;i<columns2;)
     {
    for(int j=0;j<rows2;j++)
    {
        printf("\n");
        fscanf(inFiley, "%lf",&mRNA[i][j]);
       // fprintf(outFile3," mRNA[%d][%d]  %lf\n",i,j,mRNA[i][j]);

        }
         i++;
     }
    // for(int i=0;i<columns;)
    {
        for(int j=0;j<rows1;)
        {
            ysum += mRNA[1][j];
            ysqr_sum += mRNA[1][j]*mRNA[1][j];
           // printf("ysum: %lf\n",ysum);
           // printf("ysqs: %lf\n",ysqr_sum);
            j++;
        }
    }

   for(int i=0;i<columns1;)
    {
      for(int j=0;j<rows1;)
      {
          xymul[j] = miRNA[i][j]*mRNA[1][j];
          xsqr[j] = miRNA[i][j]*miRNA[i][j];
          xsum[i] += miRNA[i][j];

          xsqr_sum[i] += xsqr[j];

          xysum[i] += xymul[j];

           j++;

      }

      num[i] = 1.0 * ((rows1 * xysum[i]) - (xsum[i] * ysum));
       deno[i] = 1.0 * ((rows1 * xsqr_sum[i] - xsum[i] * xsum[i])* (rows1 * ysqr_sum - ysum * ysum));

        //calculate correlation coefficient

       coeff[i] = (num[i] / sqrt(deno[i]));
         fprintf(outFile,"%lf\n",coeff[i]);
        i++;
    }

   printf("File copied successfully!");
    fclose(inFilex);
    fclose(inFiley);
    fclose(outFile);
    return 0;
}

/*******************************RB1 Coefficient***********************************/

int RB1_coefficient(FILE *inFilex,FILE *inFiley, int rows1, int columns1,int rows2, int columns2)
{

    double coeff[1500] ;
    double num[1500];
    double deno[1500];

    double xymul[1500] ={0.0};
    double xysum[1500] ={0.0};
    double xsum[1500]= {0.0};
    double ysum= 0.0;
    double xsqr[1500]={0.0};
    double ysqr[1500]={0.0};
    double xsqr_sum[1500]={0.0};
    double ysqr_sum=0.0;
    if (inFilex == NULL)
    {
        printf("\nFailed to open file.\n");
        exit(1);
    }

     if (inFiley == NULL)
    {
        printf("\nFailed to open file.\n");
        exit(1);
    }

     outFile = fopen("RB1_TU_coefficient.txt","w");
    if(outFile==NULL)
    {
        printf("The file was not opened.");
        exit(1);
    }


     for(int i=0;i<columns1;)
{
    printf("\n");

    for(int j=0;j<rows1;j++)
    {
        fscanf(inFilex, "%lf",&miRNA[i][j]);
       // fprintf(outFile," mRNA[%d][%d]  %lf\n",i,j,miRNA[i][j]);

        }
        i++;
    }



     for(int i=0;i<columns2;)
     {
    for(int j=0;j<rows2;j++)
    {
        printf("\n");
        fscanf(inFiley, "%lf",&mRNA[i][j]);
       // fprintf(outFile3," mRNA[%d][%d]  %lf\n",i,j,mRNA[i][j]);

        }
         i++;
     }
    // for(int i=0;i<columns;)
    {
        for(int j=0;j<rows1;)
        {
            ysum += mRNA[2][j];
            ysqr_sum += mRNA[2][j]*mRNA[2][j];
           // printf("ysum: %lf\n",ysum);
           // printf("ysqs: %lf\n",ysqr_sum);
            j++;
        }
    }

   for(int i=0;i<columns1;)
    {
      for(int j=0;j<rows1;)
      {
          xymul[j] = miRNA[i][j]*mRNA[2][j];
          xsqr[j] = miRNA[i][j]*miRNA[i][j];
          xsum[i] += miRNA[i][j];

          xsqr_sum[i] += xsqr[j];

          xysum[i] += xymul[j];

           j++;

      }

      num[i] = 1.0 * ((rows1 * xysum[i]) - (xsum[i] * ysum));
       deno[i] = 1.0 * ((rows1 * xsqr_sum[i] - xsum[i] * xsum[i])* (rows1 * ysqr_sum - ysum * ysum));

        //calculate correlation coefficient

       coeff[i] = (num[i] / sqrt(deno[i]));
         fprintf(outFile,"%lf\n",coeff[i]);
        i++;
    }

   printf("File copied successfully!");
    fclose(inFilex);
    fclose(inFiley);
    fclose(outFile);
    return 0;
}

/*******************************TP53 Coefficient***********************************/

int TP53_coefficient(FILE *inFilex,FILE *inFiley, int rows1, int columns1,int rows2, int columns2)
{

    double coeff[1500] ;
    double num[1500];
    double deno[1500];

    double xymul[1500] ={0.0};
    double xysum[1500] ={0.0};
    double xsum[1500]= {0.0};
    double ysum= 0.0;
    double xsqr[1500]={0.0};
    double ysqr[1500]={0.0};
    double xsqr_sum[1500]={0.0};
    double ysqr_sum=0.0;
    if (inFilex == NULL)
    {
        printf("\nFailed to open file.\n");
        exit(1);
    }

     if (inFiley == NULL)
    {
        printf("\nFailed to open file.\n");
        exit(1);
    }

     outFile = fopen("TP53_TU_coefficient.txt","w");
    if(outFile==NULL)
    {
        printf("The file was not opened.");
        exit(1);
    }


     for(int i=0;i<columns1;)
{
    printf("\n");

    for(int j=0;j<rows1;j++)
    {
        fscanf(inFilex, "%lf",&miRNA[i][j]);
       // fprintf(outFile," mRNA[%d][%d]  %lf\n",i,j,miRNA[i][j]);

        }
        i++;
    }



     for(int i=0;i<columns2;)
     {
    for(int j=0;j<rows2;j++)
    {
        printf("\n");
        fscanf(inFiley, "%lf",&mRNA[i][j]);
       // fprintf(outFile3," mRNA[%d][%d]  %lf\n",i,j,mRNA[i][j]);

        }
         i++;
     }
    // for(int i=0;i<columns;)
    {
        for(int j=0;j<rows1;)
        {
            ysum += mRNA[3][j];
            ysqr_sum += mRNA[3][j]*mRNA[3][j];
           // printf("ysum: %lf\n",ysum);
           // printf("ysqs: %lf\n",ysqr_sum);
            j++;
        }
    }

   for(int i=0;i<columns1;)
    {
      for(int j=0;j<rows1;)
      {
          xymul[j] = miRNA[i][j]*mRNA[3][j];
          xsqr[j] = miRNA[i][j]*miRNA[i][j];
          xsum[i] += miRNA[i][j];

          xsqr_sum[i] += xsqr[j];

          xysum[i] += xymul[j];

           j++;

      }

      num[i] = 1.0 * ((rows1 * xysum[i]) - (xsum[i] * ysum));
       deno[i] = 1.0 * ((rows1 * xsqr_sum[i] - xsum[i] * xsum[i])* (rows1 * ysqr_sum - ysum * ysum));

        //calculate correlation coefficient

       coeff[i] = (num[i] / sqrt(deno[i]));
         fprintf(outFile,"%lf\n",coeff[i]);
        i++;
    }

   printf("File copied successfully!");
    fclose(inFilex);
    fclose(inFiley);
    fclose(outFile);
    return 0;
}

/*******************************TSC1 Coefficient***********************************/

int TSC1_coefficient(FILE *inFilex,FILE *inFiley, int rows1, int columns1,int rows2, int columns2)
{

    double coeff[1500] ;
    double num[1500];
    double deno[1500];

    double xymul[1500] ={0.0};
    double xysum[1500] ={0.0};
    double xsum[1500]= {0.0}; // miRNA sum
    double ysum= 0.0; // mRNA sum
    double xsqr[1500]={0.0};
    double ysqr[1500]={0.0};
    double xsqr_sum[1500]={0.0};
    double ysqr_sum=0.0;
    if (inFilex == NULL)
    {
        printf("\nFailed to open file.\n");
        exit(1);
    }

     if (inFiley == NULL)
    {
        printf("\nFailed to open file.\n");
        exit(1);
    }

     outFile = fopen("TSC1_TU_coefficient.txt","w");
    if(outFile==NULL)
    {
        printf("The file was not opened.");
        exit(1);
    }


     for(int i=0;i<columns1;)
{
    printf("\n");

    for(int j=0;j<rows1;j++)
    {
        fscanf(inFilex, "%lf",&miRNA[i][j]);
       // fprintf(outFile," mRNA[%d][%d]  %lf\n",i,j,miRNA[i][j]);

        }
        i++;
    }



     for(int i=0;i<columns2;)
     {
    for(int j=0;j<rows2;j++)
    {
        printf("\n");
        fscanf(inFiley, "%lf",&mRNA[i][j]);
       // fprintf(outFile3," mRNA[%d][%d]  %lf\n",i,j,mRNA[i][j]);

        }
         i++;
     }
    // for(int i=0;i<columns;)
    {
        for(int j=0;j<rows1;)
        {
            ysum += mRNA[4][j];
            ysqr_sum += mRNA[4][j]*mRNA[4][j];
           // printf("ysum: %lf\n",ysum);
           // printf("ysqs: %lf\n",ysqr_sum);
            j++;
        }
    }

   for(int i=0;i<columns1;)
    {
      for(int j=0;j<rows1;)
      {
          xymul[j] = miRNA[i][j]*mRNA[4][j];
          xsqr[j] = miRNA[i][j]*miRNA[i][j];
          xsum[i] += miRNA[i][j];

          xsqr_sum[i] += xsqr[j];

          xysum[i] += xymul[j];

           j++;

      }

      num[i] = 1.0 * ((rows1 * xysum[i]) - (xsum[i] * ysum));
       deno[i] = 1.0 * ((rows1 * xsqr_sum[i] - xsum[i] * xsum[i])* (rows1 * ysqr_sum - ysum * ysum));

        //calculate correlation coefficient

       coeff[i] = (num[i] / sqrt(deno[i]));
         fprintf(outFile,"%lf\n",coeff[i]);
        i++;
    }

   printf("File copied successfully!");
    fclose(inFilex);
    fclose(inFiley);
    fclose(outFile);
    return 0;
}
