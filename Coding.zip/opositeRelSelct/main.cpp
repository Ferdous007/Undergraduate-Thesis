/********** Opposite Relation Selection between Initial 5 gene and miRNAs of Tumor and Normal Sample to find targetProfiler, targetScan and miRanda ************/

#include <bits/stdc++.h>

FILE *inFile, *inFile1, *inFile2, *inFile3, *inFile4, *inFile5,*inFile6, *inFile7, *inFile8, *inFile9, *outFile;
double TuCoeff[1500];
double NRCoeff[1500];
//int count = 0;

void fileInput();
int FGFR3_oposRelSel(FILE * , FILE * , int, int);
int HRAS_oposRelSel(FILE * , FILE * , int, int);
int RB1_oposRelSel(FILE * , FILE * , int, int);
int TP53_oposRelSel(FILE * , FILE * , int, int);
int TSC1_oposRelSel(FILE * , FILE * , int, int);

int main()
{
    fileInput();

}

void fileInput()
{
    inFile = fopen("FGFR3_TU_coefficient.txt", "r"); //53 tumor sample for FGFR3: 203 mRNA-miRNA correlation coefficient
    inFile2 =  fopen("FGFR3_coefficient.txt","r"); //11 normal sample for FGFR3: 203 mRNA-miRNA correlation coefficient

    inFile1 = fopen("HRAS_TU_coefficient.txt", "r"); //53 tumor sample for HRAS: 203 mRNA-miRNA correlation coefficient
    inFile3 =  fopen("HRAS_coefficient.txt","r"); //11 normal sample for HRAS: 203 mRNA-miRNA correlation coefficient

    inFile4 = fopen("RB1_TU_coefficient.txt", "r"); //53 tumor sample for RB1: 203 mRNA-miRNA correlation coefficient
    inFile5 =  fopen("RB1_coefficient.txt","r"); //11 normal sample for RB1: 203 mRNA-miRNA correlation coefficient

    inFile6 = fopen("TP53_TU_coefficient.txt", "r"); //53 tumor sample for TP53: 203 mRNA-miRNA correlation coefficient
    inFile7 =  fopen("TP53_coefficient.txt","r"); //11 normal sample for TP53: 203 mRNA-miRNA correlation coefficient

    inFile8 = fopen("TSC1_TU_coefficient.txt", "r"); //53 tumor sample for TSC1: 203 mRNA-miRNA correlation coefficient
    inFile9 =  fopen("TSC1_coefficient.txt","r"); //11 normal sample for TSC1: 203 mRNA-miRNA correlation coefficient


   FGFR3_oposRelSel(inFile,inFile2,204,1);
   HRAS_oposRelSel(inFile1,inFile3,204,1);
   RB1_oposRelSel(inFile4,inFile5,204,1);
   TP53_oposRelSel(inFile6,inFile7,204,1);
   TSC1_oposRelSel(inFile8,inFile9,204,1);
}

/*********************** for FGFR3 ********************/

int FGFR3_oposRelSel(FILE *inFilex , FILE *inFiley , int rows, int columns)
{
    int count=0;
    if (inFilex == NULL)
    {
        printf("\nFailed to open file.\n");
        exit(1);
    }

     if (inFiley == NULL)
    {
        printf("\nFailed to open file.\n");
        exit(1);
    }

      outFile = fopen("FGFR3_select.txt","w");
    if(outFile==NULL)
    {
        printf("The file was not opened.");
        exit(1);
    }

      //  for(int i=0;i<columns;)
{
    printf("\n");

    for(int j=0;j<rows;j++)
    {
        fscanf(inFilex, "%lf",&TuCoeff[j]);
       // printf(" tucoeff[%d]  %lf\n",j,TuCoeff[j]);
        //count++;
        }
       // i++;
    }
     for(int j=0;j<rows;j++)
    {
        fscanf(inFiley, "%lf",&NRCoeff[j]);
      //  printf(" nrcoeff[%d]  %lf\n",j,NRCoeff[j]);
       // count++;
        }
       // i++;
    for(int j=0;j<rows;j++)
    {
    if(((TuCoeff[j]<0.0 && TuCoeff[j]>-0.50) && (NRCoeff[j]>0.0&& NRCoeff[j]<1.0))||((TuCoeff[j]>0.0 && TuCoeff[j]<1.0) && (NRCoeff[j]<0.0 && NRCoeff[j]>-0.10)))
    {
       // printf("Tu: %lf \t NR: %lf\n",TuCoeff[j],NRCoeff[j]);
        fprintf(outFile,"%d: Tu: %lf \t NR: %lf\n",j,TuCoeff[j],NRCoeff[j]);
        count++;
       // fprintf("");
        //count++;
    }

}
printf("\n FGFR3 Count: %d",count);
}

/*********************** for HRAS ********************/

int HRAS_oposRelSel(FILE *inFilex , FILE *inFiley , int rows, int columns)
{
    int count=0;
    if (inFilex == NULL)
    {
        printf("\nFailed to open file.\n");
        exit(1);
    }

     if (inFiley == NULL)
    {
        printf("\nFailed to open file.\n");
        exit(1);
    }

      outFile = fopen("HRAS_select.txt","w");
    if(outFile==NULL)
    {
        printf("The file was not opened.");
        exit(1);
    }

      //  for(int i=0;i<columns;)
{
    printf("\n");

    for(int j=0;j<rows;j++)
    {
        fscanf(inFilex, "%lf",&TuCoeff[j]);
       // printf(" tucoeff[%d]  %lf\n",j,TuCoeff[j]);
        //count++;
        }
       // i++;
    }
     for(int j=0;j<rows;j++)
    {
        fscanf(inFiley, "%lf",&NRCoeff[j]);
      //  printf(" nrcoeff[%d]  %lf\n",j,NRCoeff[j]);
       // count++;
        }
       // i++;
    for(int j=0;j<rows;j++)
    {
    if(((TuCoeff[j]<0.0 && TuCoeff[j]>-0.50) && (NRCoeff[j]>0.0&& NRCoeff[j]<1.0))||((TuCoeff[j]>0.0 && TuCoeff[j]<1.0) && (NRCoeff[j]<0.0 && NRCoeff[j]>-0.10)))
    {
       // printf("Tu: %lf \t NR: %lf\n",TuCoeff[j],NRCoeff[j]);
        fprintf(outFile,"%d: Tu: %lf \t NR: %lf\n",j,TuCoeff[j],NRCoeff[j]);
        count++;
       // fprintf("");
        //count++;
    }

}
printf("\n HRAS Count: %d",count);
}

/*********************** for RB1 ********************/

int RB1_oposRelSel(FILE *inFilex , FILE *inFiley , int rows, int columns)
{
    int count=0;
    if (inFilex == NULL)
    {
        printf("\nFailed to open file.\n");
        exit(1);
    }

     if (inFiley == NULL)
    {
        printf("\nFailed to open file.\n");
        exit(1);
    }

      outFile = fopen("RB1_select.txt","w");
    if(outFile==NULL)
    {
        printf("The file was not opened.");
        exit(1);
    }

      //  for(int i=0;i<columns;)
{
    printf("\n");

    for(int j=0;j<rows;j++)
    {
        fscanf(inFilex, "%lf",&TuCoeff[j]);
       // printf(" tucoeff[%d]  %lf\n",j,TuCoeff[j]);
        //count++;
        }
       // i++;
    }
     for(int j=0;j<rows;j++)
    {
        fscanf(inFiley, "%lf",&NRCoeff[j]);
      //  printf(" nrcoeff[%d]  %lf\n",j,NRCoeff[j]);
       // count++;
        }
       // i++;
    for(int j=0;j<rows;j++)
    {
    if(((TuCoeff[j]<0.0 && TuCoeff[j]>-0.50) && (NRCoeff[j]>0.0&& NRCoeff[j]<1.0))||((TuCoeff[j]>0.0 && TuCoeff[j]<1.0) && (NRCoeff[j]<0.0 && NRCoeff[j]>-0.10)))
    {
       // printf("Tu: %lf \t NR: %lf\n",TuCoeff[j],NRCoeff[j]);
        fprintf(outFile,"%d: Tu: %lf \t NR: %lf\n",j,TuCoeff[j],NRCoeff[j]);
        count++;
       // fprintf("");
        //count++;
    }


}
printf("\n RB1 Count: %d",count);
}

/*********************** for TP53 ********************/

int TP53_oposRelSel(FILE *inFilex , FILE *inFiley , int rows, int columns)
{
    int count=0;
    if (inFilex == NULL)
    {
        printf("\nFailed to open file.\n");
        exit(1);
    }

     if (inFiley == NULL)
    {
        printf("\nFailed to open file.\n");
        exit(1);
    }

      outFile = fopen("TP53_select.txt","w");
    if(outFile==NULL)
    {
        printf("The file was not opened.");
        exit(1);
    }

      //  for(int i=0;i<columns;)
{
    printf("\n");

    for(int j=0;j<rows;j++)
    {
        fscanf(inFilex, "%lf",&TuCoeff[j]);
       // printf(" tucoeff[%d]  %lf\n",j,TuCoeff[j]);
        //count++;
        }
       // i++;
    }
     for(int j=0;j<rows;j++)
    {
        fscanf(inFiley, "%lf",&NRCoeff[j]);
      //  printf(" nrcoeff[%d]  %lf\n",j,NRCoeff[j]);
       // count++;
        }
       // i++;
    for(int j=0;j<rows;j++)
    {
    if(((TuCoeff[j]<0.0 && TuCoeff[j]>-0.50) && (NRCoeff[j]>0.0&& NRCoeff[j]<1.0))||((TuCoeff[j]>0.0 && TuCoeff[j]<1.0) && (NRCoeff[j]<0.0 && NRCoeff[j]>-0.10)))
    {
       // printf("Tu: %lf \t NR: %lf\n",TuCoeff[j],NRCoeff[j]);
        fprintf(outFile,"%d: Tu: %lf \t NR: %lf\n",j,TuCoeff[j],NRCoeff[j]);
        count++;
       // fprintf("");
        //count++;
    }


}
printf("\n TP53 Count: %d",count);
}

/*********************** for TSC1 ********************/

int TSC1_oposRelSel(FILE *inFilex , FILE *inFiley , int rows, int columns)
{
    int count=0;
    if (inFilex == NULL)
    {
        printf("\nFailed to open file.\n");
        exit(1);
    }

     if (inFiley == NULL)
    {
        printf("\nFailed to open file.\n");
        exit(1);
    }

      outFile = fopen("TSC1_select.txt","w");
    if(outFile==NULL)
    {
        printf("The file was not opened.");
        exit(1);
    }

      //  for(int i=0;i<columns;)
{
    printf("\n");

    for(int j=0;j<rows;j++)
    {
        fscanf(inFilex, "%lf",&TuCoeff[j]);
       // printf(" tucoeff[%d]  %lf\n",j,TuCoeff[j]);
        //count++;
        }
       // i++;
    }
     for(int j=0;j<rows;j++)
    {
        fscanf(inFiley, "%lf",&NRCoeff[j]);
      //  printf(" nrcoeff[%d]  %lf\n",j,NRCoeff[j]);
       // count++;
        }
       // i++;
    for(int j=0;j<rows;j++)
    {
    if(((TuCoeff[j]<0.0 && TuCoeff[j]>-0.50) && (NRCoeff[j]>0.0&& NRCoeff[j]<1.0))||((TuCoeff[j]>0.0 && TuCoeff[j]<1.0) && (NRCoeff[j]<0.0 && NRCoeff[j]>-0.10)))
    {
       // printf("Tu: %lf \t NR: %lf\n",TuCoeff[j],NRCoeff[j]);
        fprintf(outFile,"%d: Tu: %lf \t NR: %lf\n",j,TuCoeff[j],NRCoeff[j]);
        count++;
       // fprintf("");
        //count++;
    }

}
printf("\n TSC1 Count: %d",count);
}

